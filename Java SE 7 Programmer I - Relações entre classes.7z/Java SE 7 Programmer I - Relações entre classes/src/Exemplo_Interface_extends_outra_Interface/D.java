package Exemplo_Interface_extends_outra_Interface;

public interface D {
	
	
	//Exemplos de metodos a serem implementados
	public void metodoD1();
	
	public void metodoD2();	


}
