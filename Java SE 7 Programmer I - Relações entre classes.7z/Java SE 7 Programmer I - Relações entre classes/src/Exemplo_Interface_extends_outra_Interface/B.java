package Exemplo_Interface_extends_outra_Interface;

public interface B {

	
	//Exemplos de metodos a serem implementados
	public void metodoB1();
	
	public void metodoB2();	
	
}
