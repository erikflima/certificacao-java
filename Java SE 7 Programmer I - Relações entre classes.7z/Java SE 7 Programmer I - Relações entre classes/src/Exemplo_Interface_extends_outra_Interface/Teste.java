package Exemplo_Interface_extends_outra_Interface;

public class Teste implements A{

	@Override
	public void metodoA1() {	
	}

	@Override
	public void metodoA2() {
	}

	@Override
	public void metodoB1() {
	}

	@Override
	public void metodoB2() {
	}

	@Override
	public void metodoC1() {
	}

	@Override
	public void metodoC2() {
	}
	
	@Override
	public void metodoD1() {

	}

	@Override
	public void metodoD2() {
	}
}
