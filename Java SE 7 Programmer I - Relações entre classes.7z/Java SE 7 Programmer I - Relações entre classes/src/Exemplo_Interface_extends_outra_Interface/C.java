package Exemplo_Interface_extends_outra_Interface;

public interface C {
	
	
	//Exemplos de metodos a serem implementados
	public void metodoC1();
	
	public void metodoC2();	

}
