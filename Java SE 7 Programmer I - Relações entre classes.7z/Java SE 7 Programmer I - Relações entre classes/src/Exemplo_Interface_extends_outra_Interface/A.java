package Exemplo_Interface_extends_outra_Interface;

public interface A extends B, C, D {
	
	
	//Exemplos de metodos a serem implementados
	public void metodoA1();
	
	public void metodoA2();	

}
