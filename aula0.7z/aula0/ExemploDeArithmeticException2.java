package aula0;

public class ExemploDeArithmeticException2 {
	
    public static void main(String args[]){
    	
        try {
        	
            int a = 30, b = 0;
            
			/*A linha abaixo vai causar uma exception, o erro acontece aqui pois em java nao eh permitido divir um numero por zero!
			  O Java tenta executar a linha abaixo e nao consegue, entao acontece o seguinte:
			
			  1) O java verifica qual erro ocorreu, pega as informacoes do erro.
			
			  2) Agora o java precisa colocar essas informacoes em algum lugar, para que o programador possa pegar essas informacoes,
			     ai o java cria uma instancia de "ArithmeticException" que tem atributos e metodos, e preenche os atributos, e se quiser eu
			     posso pegar essa instancia usando o "catch" se eu quiser.
			
			  3) Agora o Java vai parar a execucao do programa, e nao vai executar as proximas intrucoes que estao apos a linha que causou o erro.
			  
			  4) Ai o fluxo do programa entra no "catch". Eh eh executado o que eu coloquei la. */
            int c = a / b;  
           
            System.out.println ("Resultado = " + c ); //Essa linha aqui nao vai ser executada, pois esta apos a instrucao que causou a exception
            
        }
        catch( ArithmeticException exceptionQueOJavaMePassou ) { 
        	
        	
        	/* Esse metodo "printStackTrace()" (em portugues fica "Imprima o rastro da pilha") imprimi no console algumas informacoes importantes.
        	como: a causa do erro, numero da linha que ocorreu o erro, e classe que essa linha esta*/
        	exceptionQueOJavaMePassou.printStackTrace();
        	
        	
        	System.out.println("\n\n----------Outros metodos que vi que posso pegar informacoes da exception------------------------");
        	System.out.println("Mensagem de erro extraida do metodo getLocalizedMessage(): " +exceptionQueOJavaMePassou.getLocalizedMessage() );
        	System.out.println("Mensagem de erro extraida do objeto getMessage()         : " +exceptionQueOJavaMePassou.getMessage()          );     
        	System.out.println("Mensagem de erro extraida do objeto toString()           : " +exceptionQueOJavaMePassou.toString()            );  
        	System.out.println("Mensagem de erro extraida do objeto fillInStackTrace()   : " +exceptionQueOJavaMePassou.fillInStackTrace()    ); 
        	System.out.println("Mensagem de erro extraida do objeto getCause()           : " +exceptionQueOJavaMePassou.getCause()            ); 
        	System.out.println("Mensagem de erro extraida do objeto getStackTrace()      : " +exceptionQueOJavaMePassou.getStackTrace()       ); 
        	System.out.println("Mensagem de erro extraida do objeto getClass()           : " +exceptionQueOJavaMePassou.getClass()            ); 
        	System.out.println("Mensagem de erro extraida do objeto getSuppressed()      : " +exceptionQueOJavaMePassou.getSuppressed()       ); 
        	
        }
    }
}

