package aula0;

public class ExemploDeArithmeticException {
	
    public static void main(String args[]){
    		
		int a = 30, b = 0;
		
		/*A linha abaixo vai causar uma exception, o erro acontece aqui pois em java nao eh permitido divir um numero por zero!
		  O Java tenta executar a linha abaixo e nao consegue, entao acontece o seguinte:
		
		  1) O java verifica qual erro ocorreu, pega as informacoes do erro.
		
		  2) Agora o java precisa colocar essas informacoes em algum lugar, para que o programador possa pegar essas informacoes,
		     ai o java cria uma instancia de "ArithmeticException" que tem atributos e metodos, e preenche os atributos, e se quiser eu
		     posso pegar essa instancia usando o "catch" se eu quiser.
		
		  3) Agora o Java vai parar a execucao do programa, e nao vai executar as proximas intrucoes que estao apos a linha que causou o erro.
		  
		  4) Por fim, o Java sozinho vai exibir uma mensagem de erro no console.(Essa mensagem de erro eh o mesmo que pegar a instancia de 
		     exception que o java criou e usar o metodo ".printStackTrace()", que exibe essa mensagem de erro) */
		    int c = a / b;  
		   
		    System.out.println ("Resultado = " + c ); //Essa linha aqui nao vai ser executada, pois esta apos a instrucao que causou a exception 
        
    }
}

